package com.example.a288151

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    App288151()
                }
            }
        }
    }
}

@Composable
fun App288151() {
    var aktualnyEkran by remember { mutableIntStateOf(0) }

    if (aktualnyEkran == 0) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = { aktualnyEkran = 1 },
                modifier = Modifier.fillMaxWidth(0.6f)
            ) {
                Text(text = "Ekran 1", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { aktualnyEkran = 2 },
                modifier = Modifier.fillMaxWidth(0.6f)
            ) {
                Text(text = "Ekran 2", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { aktualnyEkran = 3 },
                modifier = Modifier.fillMaxWidth(0.6f)
            ) {
                Text(text = "Ekran 3", fontSize = 18.sp)
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = aktualnyEkran.toString(),
                fontSize = 96.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { aktualnyEkran = 0 }
            ) {
                Text(text = "Powrót", fontSize = 18.sp)
            }
        }
    }
}